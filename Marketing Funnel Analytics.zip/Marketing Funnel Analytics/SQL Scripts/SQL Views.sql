-- =================================================================================
-- BATCH 1: DATABASE CREATION & 5 MASTER PRODUCTION VIEWS
-- Database: MarketingFunnelAnalytics
-- Track Code: DS (Task 3: Marketing Funnel Analytics)
-- =================================================================================

USE master;
GO

IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'MarketingFunnelAnalytics')
BEGIN
    CREATE DATABASE MarketingFunnelAnalytics;
END
GO

USE MarketingFunnelAnalytics;
GO

-- ---------------------------------------------------------------------------------
-- VIEW 1: vw_Funnel_Customer_360_Master
-- Description: Primary denormalized master view joining session facts with user,
--              marketing channel, device, and date dimensions.
-- ---------------------------------------------------------------------------------
CREATE OR ALTER VIEW vw_Funnel_Customer_360_Master AS
SELECT 
    f.session_id,
    f.user_id,
    u.user_type,
    u.region,
    m.channel,
    m.campaign_type,
    d.device,
    dt.date,
    dt.year_month,
    dt.month_name,
    dt.day_of_week,
    dt.is_weekend,
    CAST(f.visited_website_flag AS INT) AS visited_website_flag,
    CAST(f.viewed_product_flag AS INT) AS viewed_product_flag,
    CAST(f.added_to_cart_flag AS INT) AS added_to_cart_flag,
    CAST(f.checkout_started_flag AS INT) AS checkout_started_flag,
    CAST(f.purchase_completed_flag AS INT) AS purchase_completed_flag,
    CAST(f.discount_applied_flag AS INT) AS discount_applied_flag,
    f.completed_stage_num,
    f.furthest_funnel_stage,
    f.dropoff_stage,
    CAST(f.order_value AS DECIMAL(12,2)) AS order_value,
    CAST(f.revenue AS DECIMAL(12,2)) AS revenue
FROM Fact_Funnel_Sessions f
LEFT JOIN Dim_User u      ON f.user_id = u.user_id
LEFT JOIN Dim_Marketing m ON f.marketing_id = m.marketing_id
LEFT JOIN Dim_Device d    ON f.device_id = d.device_id
LEFT JOIN Dim_Date dt     ON f.date_key = dt.date_key;
GO

-- ---------------------------------------------------------------------------------
-- VIEW 2: vw_Funnel_Stage_Conversion_Summary
-- Description: Aggregates total traffic volume and conversion counts across
--              all 5 funnel stages with overall conversion percentages.
-- ---------------------------------------------------------------------------------
CREATE OR ALTER VIEW vw_Funnel_Stage_Conversion_Summary AS
SELECT 
    COUNT(session_id) AS Total_Sessions,
    SUM(CAST(visited_website_flag AS INT)) AS Stage1_Website_Visitors,
    SUM(CAST(viewed_product_flag AS INT)) AS Stage2_Product_Viewers,
    SUM(CAST(added_to_cart_flag AS INT)) AS Stage3_Cart_Additions,
    SUM(CAST(checkout_started_flag AS INT)) AS Stage4_Checkout_Initiated,
    SUM(CAST(purchase_completed_flag AS INT)) AS Stage5_Purchases_Completed,
    CAST(ROUND((SUM(CAST(viewed_product_flag AS INT)) * 100.0) / COUNT(session_id), 2) AS DECIMAL(5,2)) AS Product_View_Rate_Pct,
    CAST(ROUND((SUM(CAST(added_to_cart_flag AS INT)) * 100.0) / COUNT(session_id), 2) AS DECIMAL(5,2)) AS Cart_Add_Rate_Pct,
    CAST(ROUND((SUM(CAST(checkout_started_flag AS INT)) * 100.0) / COUNT(session_id), 2) AS DECIMAL(5,2)) AS Checkout_Rate_Pct,
    CAST(ROUND((SUM(CAST(purchase_completed_flag AS INT)) * 100.0) / COUNT(session_id), 2) AS DECIMAL(5,2)) AS Overall_Conversion_Rate_Pct,
    CAST(ROUND(SUM(revenue), 2) AS DECIMAL(12,2)) AS Total_Net_Revenue
FROM Fact_Funnel_Sessions;
GO

-- ---------------------------------------------------------------------------------
-- VIEW 3: vw_Channel_Campaign_ROAS_Performance
-- Description: Channel and campaign level breakdown evaluating sessions, conversions,
--              total revenue, average order value (AOV), and revenue per session.
-- ---------------------------------------------------------------------------------
CREATE OR ALTER VIEW vw_Channel_Campaign_ROAS_Performance AS
SELECT 
    m.channel,
    m.campaign_type,
    COUNT(f.session_id) AS Total_Sessions,
    SUM(CAST(f.purchase_completed_flag AS INT)) AS Total_Purchases,
    CAST(ROUND((SUM(CAST(f.purchase_completed_flag AS INT)) * 100.0) / COUNT(f.session_id), 2) AS DECIMAL(5,2)) AS Conversion_Rate_Pct,
    CAST(ROUND(SUM(f.revenue), 2) AS DECIMAL(12,2)) AS Total_Revenue,
    CAST(ROUND(AVG(CASE WHEN CAST(f.purchase_completed_flag AS INT) = 1 THEN f.order_value END), 2) AS DECIMAL(10,2)) AS Avg_Order_Value,
    CAST(ROUND(SUM(f.revenue) / COUNT(f.session_id), 2) AS DECIMAL(10,2)) AS Revenue_Per_Session
FROM Fact_Funnel_Sessions f
LEFT JOIN Dim_Marketing m ON f.marketing_id = m.marketing_id
GROUP BY m.channel, m.campaign_type;
GO

-- ---------------------------------------------------------------------------------
-- VIEW 4: vw_Cart_Checkout_Dropoff_Watchlist
-- Description: Identifies high-intent abandoned sessions (Added to Cart or
--              Checkout Started) that dropped off before purchase completion.
-- ---------------------------------------------------------------------------------
CREATE OR ALTER VIEW vw_Cart_Checkout_Dropoff_Watchlist AS
SELECT 
    f.session_id,
    f.user_id,
    u.user_type,
    u.region,
    m.channel,
    d.device,
    f.completed_stage_num,
    f.furthest_funnel_stage,
    f.dropoff_stage,
    CAST(f.order_value AS DECIMAL(12,2)) AS Abandoned_Order_Value
FROM Fact_Funnel_Sessions f
LEFT JOIN Dim_User u      ON f.user_id = u.user_id
LEFT JOIN Dim_Marketing m ON f.marketing_id = m.marketing_id
LEFT JOIN Dim_Device d    ON f.device_id = d.device_id
WHERE CAST(f.added_to_cart_flag AS INT) = 1 
  AND CAST(f.purchase_completed_flag AS INT) = 0;
GO

-- ---------------------------------------------------------------------------------
-- VIEW 5: vw_Device_Regional_Conversion_Executive
-- Description: Regional (Metro vs Non-Metro) and Device (Mobile vs Desktop)
--              conversion performance matrix.
-- ---------------------------------------------------------------------------------
CREATE OR ALTER VIEW vw_Device_Regional_Conversion_Executive AS
SELECT 
    d.device,
    u.region,
    u.user_type,
    COUNT(f.session_id) AS Total_Sessions,
    SUM(CAST(f.added_to_cart_flag AS INT)) AS Cart_Additions,
    SUM(CAST(f.purchase_completed_flag AS INT)) AS Total_Purchases,
    CAST(ROUND((SUM(CAST(f.purchase_completed_flag AS INT)) * 100.0) / COUNT(f.session_id), 2) AS DECIMAL(5,2)) AS Conversion_Rate_Pct,
    CAST(ROUND(SUM(f.revenue), 2) AS DECIMAL(12,2)) AS Total_Revenue
FROM Fact_Funnel_Sessions f
LEFT JOIN Dim_User u   ON f.user_id = u.user_id
LEFT JOIN Dim_Device d ON f.device_id = d.device_id
GROUP BY d.device, u.region, u.user_type;
GO