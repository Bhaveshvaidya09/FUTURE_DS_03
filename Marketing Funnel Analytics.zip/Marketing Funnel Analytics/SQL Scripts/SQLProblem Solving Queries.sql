-- =================================================================================
-- BATCH 2: 10 ADVANCED BUSINESS PROBLEM-SOLVING T-SQL QUERIES
-- Database: MarketingFunnelAnalytics
-- Description: Utilizes CTEs, Window Functions (DENSE_RANK, LAG, SUM OVER), 
--              aggregations, and stage drop-off logic to solve marketing growth tasks.
-- =================================================================================

USE MarketingFunnelAnalytics;
GO

-- ---------------------------------------------------------------------------------
-- QUERY 1: Executive Baseline — Overall 5-Stage Funnel & Revenue Exposure
-- Problem: What is the executive baseline for total sessions, stage volumes, 
--          overall conversion rate, and total net revenue?
-- ---------------------------------------------------------------------------------
SELECT 
    COUNT(session_id) AS Total_Sessions,
    SUM(CAST(visited_website_flag AS INT)) AS Visited_Website,
    SUM(CAST(viewed_product_flag AS INT)) AS Viewed_Product,
    SUM(CAST(added_to_cart_flag AS INT)) AS Added_To_Cart,
    SUM(CAST(checkout_started_flag AS INT)) AS Checkout_Started,
    SUM(CAST(purchase_completed_flag AS INT)) AS Purchases_Completed,
    CAST(ROUND((SUM(CAST(purchase_completed_flag AS INT)) * 100.0) / COUNT(session_id), 2) AS DECIMAL(5,2)) AS Overall_Conversion_Rate_Pct,
    CAST(ROUND(SUM(revenue), 2) AS DECIMAL(12,2)) AS Total_Net_Revenue,
    CAST(ROUND(SUM(revenue) / COUNT(session_id), 2) AS DECIMAL(10,2)) AS Revenue_Per_Session
FROM Fact_Funnel_Sessions;

-- ---------------------------------------------------------------------------------
-- QUERY 2: Stage-by-Stage Step-Down Conversion & Drop-off Velocity Matrix
-- Problem: What is the exact conversion and drop-off percentage between consecutive funnel stages?
-- ---------------------------------------------------------------------------------
WITH FunnelStageCTE AS (
    SELECT 
        COUNT(session_id) AS S1_Visitors,
        SUM(CAST(viewed_product_flag AS INT)) AS S2_Product_Viewers,
        SUM(CAST(added_to_cart_flag AS INT)) AS S3_Cart_Additions,
        SUM(CAST(checkout_started_flag AS INT)) AS S4_Checkouts,
        SUM(CAST(purchase_completed_flag AS INT)) AS S5_Purchases
    FROM Fact_Funnel_Sessions
)
SELECT 
    S1_Visitors,
    S2_Product_Viewers,
    CAST(ROUND((S2_Product_Viewers * 100.0) / S1_Visitors, 2) AS DECIMAL(5,2)) AS S1_to_S2_Conversion_Pct,
    CAST(ROUND(100.0 - ((S2_Product_Viewers * 100.0) / S1_Visitors), 2) AS DECIMAL(5,2)) AS S1_to_S2_Dropoff_Pct,
    S3_Cart_Additions,
    CAST(ROUND((S3_Cart_Additions * 100.0) / S2_Product_Viewers, 2) AS DECIMAL(5,2)) AS S2_to_S3_Conversion_Pct,
    CAST(ROUND(100.0 - ((S3_Cart_Additions * 100.0) / S2_Product_Viewers), 2) AS DECIMAL(5,2)) AS S2_to_S3_Dropoff_Pct,
    S4_Checkouts,
    CAST(ROUND((S4_Checkouts * 100.0) / S3_Cart_Additions, 2) AS DECIMAL(5,2)) AS S3_to_S4_Conversion_Pct,
    CAST(ROUND(100.0 - ((S4_Checkouts * 100.0) / S3_Cart_Additions), 2) AS DECIMAL(5,2)) AS S3_to_S4_Dropoff_Pct,
    S5_Purchases,
    CAST(ROUND((S5_Purchases * 100.0) / S4_Checkouts, 2) AS DECIMAL(5,2)) AS S4_to_S5_Conversion_Pct,
    CAST(ROUND(100.0 - ((S5_Purchases * 100.0) / S4_Checkouts), 2) AS DECIMAL(5,2)) AS S4_to_S5_Dropoff_Pct
FROM FunnelStageCTE;

-- ---------------------------------------------------------------------------------
-- QUERY 3: Channel Performance & Conversion Efficiency Ranking (DENSE_RANK)
-- Problem: Which marketing acquisition channel yields the highest conversion rate and net revenue?
-- ---------------------------------------------------------------------------------
WITH ChannelRankCTE AS (
    SELECT 
        m.channel,
        COUNT(f.session_id) AS Total_Sessions,
        SUM(CAST(f.purchase_completed_flag AS INT)) AS Total_Purchases,
        SUM(f.revenue) AS Total_Revenue,
        (SUM(CAST(f.purchase_completed_flag AS INT)) * 100.0) / COUNT(f.session_id) AS Conversion_Rate
    FROM Fact_Funnel_Sessions f
    LEFT JOIN Dim_Marketing m ON f.marketing_id = m.marketing_id
    GROUP BY m.channel
)
SELECT 
    channel,
    Total_Sessions,
    Total_Purchases,
    CAST(ROUND(Conversion_Rate, 2) AS DECIMAL(5,2)) AS Conversion_Rate_Pct,
    CAST(ROUND(Total_Revenue, 2) AS DECIMAL(12,2)) AS Total_Revenue,
    DENSE_RANK() OVER(ORDER BY Total_Revenue DESC) AS Revenue_Rank,
    DENSE_RANK() OVER(ORDER BY Conversion_Rate DESC) AS Conversion_Rank
FROM ChannelRankCTE
ORDER BY Revenue_Rank ASC;

-- ---------------------------------------------------------------------------------
-- QUERY 4: Campaign Type & Promotional Discount Impact Matrix
-- Problem: Does applying promotional discounts significantly increase conversion rate across campaign types?
-- ---------------------------------------------------------------------------------
SELECT 
    m.campaign_type,
    CASE WHEN CAST(f.discount_applied_flag AS INT) = 1 THEN 'Discount Applied' ELSE 'No Discount' END AS Discount_Status,
    COUNT(f.session_id) AS Session_Count,
    SUM(CAST(f.purchase_completed_flag AS INT)) AS Purchases,
    CAST(ROUND((SUM(CAST(f.purchase_completed_flag AS INT)) * 100.0) / COUNT(f.session_id), 2) AS DECIMAL(5,2)) AS Conversion_Rate_Pct,
    CAST(ROUND(SUM(f.revenue), 2) AS DECIMAL(12,2)) AS Total_Revenue,
    CAST(ROUND(AVG(CASE WHEN CAST(f.purchase_completed_flag AS INT) = 1 THEN f.order_value END), 2) AS DECIMAL(10,2)) AS Avg_Order_Value
FROM Fact_Funnel_Sessions f
LEFT JOIN Dim_Marketing m ON f.marketing_id = m.marketing_id
GROUP BY m.campaign_type, CAST(f.discount_applied_flag AS INT)
ORDER BY m.campaign_type, Conversion_Rate_Pct DESC;

-- ---------------------------------------------------------------------------------
-- QUERY 5: High-Intent Cart & Checkout Abandonment Revenue Leakage
-- Problem: How much potential revenue is lost specifically at the Cart Addition and Checkout Started drop-off points?
-- ---------------------------------------------------------------------------------
SELECT 
    f.dropoff_stage,
    COUNT(f.session_id) AS Abandoned_Sessions,
    CAST(ROUND(SUM(f.order_value), 2) AS DECIMAL(12,2)) AS Lost_Potential_Order_Value,
    CAST(ROUND((COUNT(f.session_id) * 100.0) / (SELECT COUNT(*) FROM Fact_Funnel_Sessions), 2) AS DECIMAL(5,2)) AS Pct_Of_Total_Sessions
FROM Fact_Funnel_Sessions f
WHERE f.dropoff_stage IN ('Drop-off at Cart', 'Drop-off at Checkout')
GROUP BY f.dropoff_stage
ORDER BY Lost_Potential_Order_Value DESC;

-- ---------------------------------------------------------------------------------
-- QUERY 6: Mobile vs Desktop Regional Conversion Friction Matrix
-- Problem: Are mobile users in Metro vs Non-Metro regions experiencing higher checkout friction?
-- ---------------------------------------------------------------------------------
SELECT 
    d.device,
    u.region,
    COUNT(f.session_id) AS Total_Sessions,
    SUM(CAST(f.added_to_cart_flag AS INT)) AS Cart_Additions,
    SUM(CAST(f.checkout_started_flag AS INT)) AS Checkouts,
    SUM(CAST(f.purchase_completed_flag AS INT)) AS Purchases,
    CAST(ROUND((SUM(CAST(f.purchase_completed_flag AS INT)) * 100.0) / COUNT(f.session_id), 2) AS DECIMAL(5,2)) AS Conversion_Rate_Pct,
    CAST(ROUND(SUM(f.revenue), 2) AS DECIMAL(12,2)) AS Total_Revenue
FROM Fact_Funnel_Sessions f
LEFT JOIN Dim_User u   ON f.user_id = u.user_id
LEFT JOIN Dim_Device d ON f.device_id = d.device_id
GROUP BY d.device, u.region
ORDER BY Conversion_Rate_Pct DESC;

-- ---------------------------------------------------------------------------------
-- QUERY 7: New vs Returning User Conversion & Average Order Value Comparison
-- Problem: Do returning users convert at higher rates and generate higher AOV compared to new visitors?
-- ---------------------------------------------------------------------------------
SELECT 
    u.user_type,
    COUNT(f.session_id) AS Total_Sessions,
    COUNT(DISTINCT f.user_id) AS Unique_Users,
    SUM(CAST(f.purchase_completed_flag AS INT)) AS Purchases,
    CAST(ROUND((SUM(CAST(f.purchase_completed_flag AS INT)) * 100.0) / COUNT(f.session_id), 2) AS DECIMAL(5,2)) AS Conversion_Rate_Pct,
    CAST(ROUND(SUM(f.revenue), 2) AS DECIMAL(12,2)) AS Total_Revenue,
    CAST(ROUND(AVG(CASE WHEN CAST(f.purchase_completed_flag AS INT) = 1 THEN f.order_value END), 2) AS DECIMAL(10,2)) AS Avg_Order_Value
FROM Fact_Funnel_Sessions f
LEFT JOIN Dim_User u ON f.user_id = u.user_id
GROUP BY u.user_type;

-- ---------------------------------------------------------------------------------
-- QUERY 8: Monthly Revenue Trajectory & Month-over-Month (MoM) Growth (LAG Function)
-- Problem: What is the month-over-month net revenue growth percentage across the 6-month period?
-- ---------------------------------------------------------------------------------
WITH MonthlyRevenueCTE AS (
    SELECT 
        dt.year_month,
        COUNT(f.session_id) AS Monthly_Sessions,
        SUM(CAST(f.purchase_completed_flag AS INT)) AS Monthly_Purchases,
        SUM(f.revenue) AS Monthly_Revenue
    FROM Fact_Funnel_Sessions f
    LEFT JOIN Dim_Date dt ON f.date_key = dt.date_key
    GROUP BY dt.year_month
)
SELECT 
    year_month,
    Monthly_Sessions,
    Monthly_Purchases,
    CAST(ROUND(Monthly_Revenue, 2) AS DECIMAL(12,2)) AS Monthly_Revenue,
    CAST(ROUND(LAG(Monthly_Revenue, 1) OVER(ORDER BY year_month ASC), 2) AS DECIMAL(12,2)) AS Prior_Month_Revenue,
    CAST(ROUND(((Monthly_Revenue - LAG(Monthly_Revenue, 1) OVER(ORDER BY year_month ASC)) * 100.0) / 
          NULLIF(LAG(Monthly_Revenue, 1) OVER(ORDER BY year_month ASC), 0), 2) AS DECIMAL(5,2)) AS MoM_Revenue_Growth_Pct
FROM MonthlyRevenueCTE
ORDER BY year_month ASC;

-- ---------------------------------------------------------------------------------
-- QUERY 9: Top 20 High-Value Converting Customers & Pareto Cumulative Revenue (SUM OVER)
-- Problem: Who are the top 20 highest-spending converted customers and their cumulative revenue contribution?
-- ---------------------------------------------------------------------------------
WITH CustomerRevenueCTE AS (
    SELECT TOP 20
        f.user_id,
        u.user_type,
        u.region,
        COUNT(f.session_id) AS Converted_Sessions,
        SUM(f.revenue) AS Total_User_Revenue
    FROM Fact_Funnel_Sessions f
    LEFT JOIN Dim_User u ON f.user_id = u.user_id
    WHERE CAST(f.purchase_completed_flag AS INT) = 1
    GROUP BY f.user_id, u.user_type, u.region
    ORDER BY Total_User_Revenue DESC
)
SELECT 
    user_id,
    user_type,
    region,
    Converted_Sessions,
    CAST(ROUND(Total_User_Revenue, 2) AS DECIMAL(12,2)) AS Total_User_Revenue,
    CAST(ROUND(SUM(Total_User_Revenue) OVER(ORDER BY Total_User_Revenue DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW), 2) AS DECIMAL(12,2)) AS Cumulative_Revenue
FROM CustomerRevenueCTE
ORDER BY Total_User_Revenue DESC;

-- ---------------------------------------------------------------------------------
-- QUERY 10: Weekday vs Weekend Conversion Dynamics Analysis
-- Problem: Does user purchasing behavior and conversion efficiency vary between weekdays and weekends?
-- ---------------------------------------------------------------------------------
SELECT 
    CASE WHEN dt.is_weekend = 1 THEN 'Weekend' ELSE 'Weekday' END AS Day_Category,
    COUNT(f.session_id) AS Total_Sessions,
    SUM(CAST(f.added_to_cart_flag AS INT)) AS Cart_Additions,
    SUM(CAST(f.purchase_completed_flag AS INT)) AS Purchases,
    CAST(ROUND((SUM(CAST(f.purchase_completed_flag AS INT)) * 100.0) / COUNT(f.session_id), 2) AS DECIMAL(5,2)) AS Conversion_Rate_Pct,
    CAST(ROUND(SUM(f.revenue), 2) AS DECIMAL(12,2)) AS Total_Revenue,
    CAST(ROUND(SUM(f.revenue) / COUNT(f.session_id), 2) AS DECIMAL(10,2)) AS Revenue_Per_Session
FROM Fact_Funnel_Sessions f
LEFT JOIN Dim_Date dt ON f.date_key = dt.date_key
GROUP BY dt.is_weekend
ORDER BY Conversion_Rate_Pct DESC;